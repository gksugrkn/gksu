import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class App {

public static void main(String[] args) throws FileNotFoundException, IOException {
    
    Scanner scn = new Scanner(System.in);

    System.out.println("Please enter name for player1: ");
    Player player1 = new Player(1, scn.nextLine());
    System.out.println("Please enter name for player2: ");
    Player player2 = new Player(2, scn.nextLine());;

    Game game = new Game(0);
    game.startGame(player1, player2, scn);
    

}
    
}

