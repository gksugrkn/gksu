public class BattleResult {
    private Player wonPlayer;
    private Player loserPlayer;
    private Monster wonMonster;
    private Monster loserMonster;

    public Player getWonPlayer() {
        return wonPlayer;
    }

    public void setWonPlayer(Player wonPlayer) {
        this.wonPlayer = wonPlayer;
    }

    public Player getLoserPlayer() {
        return loserPlayer;
    }

    public void setLoserPlayer(Player loserPlayer) {
        this.loserPlayer = loserPlayer;
    }

    public Monster getWonMonster() {
        return wonMonster;
    }

    public void setWonMonster(Monster wonMonster) {
        this.wonMonster = wonMonster;
    }

    public Monster getLoserMonster() {
        return loserMonster;
    }

    public void setLoserMonster(Monster loserMonster) {
        this.loserMonster = loserMonster;
    }
}
