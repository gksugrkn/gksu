import java.util.Comparator;

public class MonsterTree {
    private MonsterNode root;
    private Comparator<Monster> comparator;

    public MonsterTree(Comparator<Monster> comparator) {
        this.comparator = comparator;
        this.root = null;
    }

    // Tree insertion
    public void insert(Monster monster) {
        root = insertRec(root, monster);
    }

    private MonsterNode insertRec(MonsterNode root, Monster monster) {
        if (root == null) {
            root = new MonsterNode(monster);
            return root;
        }
        if (comparator.compare(monster, root.monster) < 0) {
            root.left = insertRec(root.left, monster);
        } else if (comparator.compare(monster, root.monster) > 0) {
            root.right = insertRec(root.right, monster);
        }
        return root;
    }

    // Tree removal
    public void remove(int id) {
        root = removeRec(root, id);
    }

    private MonsterNode removeRec(MonsterNode root, int id) {
        if (root == null) {
            return null;
        }
        if (id < root.monster.getId()) {
            root.left = removeRec(root.left, id);
        } else if (id > root.monster.getId()) {
            root.right = removeRec(root.right, id);
        } else {
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }
            root.monster = minValue(root.right);
            root.right = removeRec(root.right, root.monster.getId());
        }
        return root;
    }

    private Monster minValue(MonsterNode root) {
        Monster minValue = root.monster;
        while (root.left != null) {
            minValue = root.left.monster;
            root = root.left;
        }
        return minValue;
    }

    // Traversal for displaying
    public void inOrderTraversal() {
        inOrderRec(root);
    }

    private void inOrderRec(MonsterNode root) {
        if (root != null) {
            inOrderRec(root.left);
            System.out.println(root.monster);
            inOrderRec(root.right);
        }
    }

    // Find a monster by ID
    public Monster findMonsterById(int id) {
        return findMonsterByIdRec(root, id);
    }

    private Monster findMonsterByIdRec(MonsterNode root, int id) {
        if (root == null) {
            return null;
        }
        if (id < root.monster.getId()) {
            return findMonsterByIdRec(root.left, id);
        } else if (id > root.monster.getId()) {
            return findMonsterByIdRec(root.right, id);
        } else {
            return root.monster;
        }
    }

    // Internal node class
    private static class MonsterNode {
        Monster monster;
        MonsterNode left, right;

        public MonsterNode(Monster monster) {
            this.monster = monster;
            this.left = null;
            this.right = null;
        }
    }
}
