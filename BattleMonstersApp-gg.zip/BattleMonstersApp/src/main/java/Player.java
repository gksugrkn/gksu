import java.util.Hashtable;
import java.util.TreeSet;
public class Player {

    int id;
    String name;
    int winStreak;
    Hashtable<Integer, Monster> monsters;
    TreeSet<Monster> sortedMonsters;  // TreeSet for sorted monsters

    public Player(int id, String name) {
        this.id = id;
        this.name = name;
        this.winStreak = 0;
        this.monsters = new Hashtable<>();

        // Anonim sınıf ile Comparator tanımlama
        this.sortedMonsters = new TreeSet<>((Monster m1, Monster m2) -> Integer.compare(m1.getId(), m2.getId()) // Default olarak ID'ye göre sıralama
        );
    }

    // Getter metodları
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getWinStreak() {
        return winStreak;
    }

    public Hashtable<Integer, Monster> getMonsters() {
        return monsters;
    }

    public TreeSet<Monster> getSortedMonsters() {
        return sortedMonsters;
    }

    // Setter metodları
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setWinStreak(int winStreak) {
        this.winStreak = winStreak;
    }

    public void setMonsters(Hashtable<Integer, Monster> monsters) {
        this.monsters = monsters;
        this.sortedMonsters.clear();
        this.sortedMonsters.addAll(monsters.values());
    }

    public void setSortedMonsters(TreeSet<Monster> sortedMonsters) {
        this.sortedMonsters = sortedMonsters;
    }

    void listPlayersMonsters() {
        for (Monster value : monsters.values()) {
            System.out.println(value.toString());
        }

    }

    @Override
    public String toString() {
        return "Player Name: " + name + ", Win Streak: " + winStreak;
    }
}
