import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Hashtable;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Comparator;

public final class Game {
    int gameID;
    List<Player> playerList;
    Hashtable<Integer, Monster> monstersHashtable;
    MonsterTree monsterTree;
    Monster player1Monster;
    Monster player2Monster;
    int player1MonsterId;
    int player2MonsterId;

    public Game(int gameID) {
        this.gameID = gameID;
        this.monstersHashtable = new Hashtable<>();
        this.monsterTree = new MonsterTree(Comparator.comparingInt(Monster::getId));
        this.playerList = new ArrayList<>();
        try {
            txtToMonsterHashtable();
        } catch (FileNotFoundException e) {
            System.out.println("Dosya bulunamadı: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Bir I/O hatası oluştu: " + e.getMessage());
        }
        txtToMonsterTree();
    }

    void txtToMonsterHashtable() throws FileNotFoundException, IOException {
        String filePath = "C:\\Users\\Göksu-GÜRKAN\\Documents\\NetBeansProjects\\BattleMonstersApp\\src\\main\\java\\monsters.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                int id = Integer.parseInt(line.trim());
                String name = br.readLine().trim();
                int health = Integer.parseInt(br.readLine().trim());
                int attack = Integer.parseInt(br.readLine().trim());
                int defense = Integer.parseInt(br.readLine().trim());
                int level = Integer.parseInt(br.readLine().trim());

                Monster monster = new Monster(id, name, health, attack, defense, level);
                monstersHashtable.put(id, monster);
            }
        }
    }

    void startGame(Player player1, Player player2, Scanner scn) {
        listMonsters();
        System.out.println("Pick 10 monsters from the list (type monster id for picking):");
        selectMonstersForPlayer(player1, scn);
        selectMonstersForPlayer(player2, scn);

        // Show Player 1 and Player 2's selected monsters before starting the battle
        System.out.println(player1.getName() + "'s selected monsters:");
        listPlayerMonstersWithDetails(player1);

        System.out.println(player2.getName() + "'s selected monsters:");
        listPlayerMonstersWithDetails(player2);

        System.out.println("******** BATTLE STARTING ********");

        setPlayerList(player1, player2);

        while (player1.getWinStreak() < 3 && player2.getWinStreak() < 3
                && !player1.getMonsters().isEmpty() && !player2.getMonsters().isEmpty()) {
            startBattle(scn);
            BattleResult battleResult = monsterBattle();

            if (battleResult != null) {
                updatePlayers(battleResult); // Oyuncuları güncelle
            } else {
                System.out.println("Error: Battle result is null.");
                break; // BattleResult null ise döngüyü kır
            }

            showPlayersWin(); // Oyuncu zaferlerini göster

            // Kontrol ve çıkış için ekleme
            if (player1.getWinStreak() >= 3 || player2.getWinStreak() >= 3) {
                System.out.println("Game Over!");
                break; // Döngüyü kır, bir oyuncu 3 zafer serisi tamamladıysa
            }
        }
    }

    void startBattle(Scanner scn) {
        Player player1 = playerList.get(0);
        Player player2 = playerList.get(1);

        player1Monster = null;
        player2Monster = null;

        while (player1Monster == null) {
            player1.listPlayersMonsters();
            System.out.println(player1.getName() + ", pick one monster from your monster list: ");
            player1MonsterId = getValidMonsterId(scn);
            if (player1.getMonsters().containsKey(player1MonsterId)) {
                player1Monster = player1.getMonsters().get(player1MonsterId);
            } else {
                System.out.println("You don't have a monster with ID: " + player1MonsterId);
            }
        }

        while (player2Monster == null) {
            player2.listPlayersMonsters();
            System.out.println(player2.getName() + ", pick one monster from your monster list: ");
            player2MonsterId = getValidMonsterId(scn);
            if (player2.getMonsters().containsKey(player2MonsterId)) {
                player2Monster = player2.getMonsters().get(player2MonsterId);
            } else {
                System.out.println("You don't have a monster with ID: " + player2MonsterId);
            }
        }
    }

    BattleResult monsterBattle() {
        BattleResult battleResult = new BattleResult();

        while (player1Monster.getHealth() > 0 && player2Monster.getHealth() > 0) {
            // Player 1's monster attacks Player 2's monster
            processAttack(player1Monster, player2Monster, battleResult, playerList.get(0), playerList.get(1));
            if (player2Monster.getHealth() <= 0) break;

            // Player 2's monster attacks Player 1's monster
            processAttack(player2Monster, player1Monster, battleResult, playerList.get(1), playerList.get(0));
        }

        // Displaying the selected monster IDs and names at the end of the battle
        System.out.println("Battle Summary:");
        System.out.println(playerList.get(0).getName() + " selected monster: " + player1Monster.getName() + " (ID: " + player1MonsterId + ")");
        System.out.println(playerList.get(1).getName() + " selected monster: " + player2Monster.getName() + " (ID: " + player2MonsterId + ")");

        return battleResult;
    }

    void processAttack(Monster attacker, Monster defender, BattleResult battleResult, Player attackerPlayer, Player defenderPlayer) {
        defender.setDefense(defender.getDefense() - attacker.getAttack());
        if (defender.getDefense() < 0) {
            defender.setHealth(defender.getHealth() + defender.getDefense());
            defender.setDefense(0);
        }

        if (defender.getHealth() <= 0) {
            System.out.println(attackerPlayer.getName() + "'s monster " + attacker.getName() + " wins!");
            attacker.setLevel(attacker.getLevel() + 1);
            battleResult.setWonPlayer(attackerPlayer);
            battleResult.setWonMonster(attacker);
            battleResult.setLoserMonster(defender);
            battleResult.setLoserPlayer(defenderPlayer);
        }
    }

    void updatePlayers(BattleResult battleResult) {
        if (battleResult != null) {
            Player wonPlayer = battleResult.getWonPlayer();
            Player loserPlayer = battleResult.getLoserPlayer();
            Monster wonMonster = battleResult.getWonMonster();
            Monster loserMonster = battleResult.getLoserMonster();

            if (wonPlayer != null && wonMonster != null) {
                // Kazanan oyuncuyu güncelle
                wonPlayer.setWinStreak(wonPlayer.getWinStreak() + 1);
                wonPlayer.getMonsters().put(wonMonster.getId(), wonMonster);
                System.out.println("Winner's Monster Details: " + wonMonster.toString());
            } else {
                System.out.println("Error: No winning player or monster found.");
            }

            if (loserPlayer != null && loserMonster != null) {
                // Kaybeden oyuncuyu güncelle
                loserPlayer.setWinStreak(0);
                loserPlayer.getMonsters().remove(loserMonster.getId());
            } else {
                System.out.println("Error: No losing player or monster found.");
            }
        } else {
            System.out.println("Error: Battle result is null.");
        }
    }

    void selectMonstersForPlayer(Player player, Scanner scn) {
        while (player.getMonsters().size() < 10) {
            System.out.println("Available monsters:");
            listAllMonstersWithDetails(); // Show all available monsters
            System.out.println(player.getName() + ", type the ID of the monster you want to pick: ");
            int id = getValidMonsterId(scn);
            if (!monstersHashtable.containsKey(id)) {
                System.out.println("Monster is not in list");
            } else if (player.getMonsters().containsKey(id)) {
                System.out.println("Monster with ID " + id + " is already selected.");
            } else {
                player.getMonsters().put(id, monstersHashtable.get(id));
                System.out.println("Monster with ID " + id + " added to your list.");
                System.out.println("Your current monsters:");
                listPlayerMonstersWithDetails(player); // Show current player's selected monsters
            }
        }
    }

    void listAllMonstersWithDetails() {
        for (Monster monster : monstersHashtable.values()) {
            System.out.println("ID: " + monster.getId() + ", Name: " + monster.getName() + 
                ", Health: " + monster.getHealth() + ", Attack: " + monster.getAttack() + 
                ", Defense: " + monster.getDefense() + ", Level: " + monster.getLevel());
        }
    }

    void listPlayerMonstersWithDetails(Player player) {
        for (Monster monster : player.getMonsters().values()) {
            System.out.println("ID: " + monster.getId() + ", Name: " + monster.getName() + 
                ", Health: " + monster.getHealth() + ", Attack: " + monster.getAttack() + 
                ", Defense: " + monster.getDefense() + ", Level: " + monster.getLevel());
        }
    }

    int getValidMonsterId(Scanner scn) {
        int id = 0;
        boolean valid = false;
        while (!valid) {
            try {
                id = scn.nextInt();
                valid = true;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! You can enter only numbers.");
                scn.next();
            }
        }
        return id;
    }

    public void showPlayersWin() {
        for (Player player : playerList) {
            System.out.println(player.toString());
        }
    }

    void listMonsters() {
        monsterTree.inOrderTraversal(); // Display using tree
    }

    void setPlayerList(Player player1, Player player2) {
        playerList.add(player1);
        playerList.add(player2);
    }

    // Load monsters from text file into the tree
    void txtToMonsterTree() {
        for (Monster monster : monstersHashtable.values()) {
            monsterTree.insert(monster);
        }
    }
}
